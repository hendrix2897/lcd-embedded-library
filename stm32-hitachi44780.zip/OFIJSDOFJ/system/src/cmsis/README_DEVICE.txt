The system_stm32f10x.c file is from stsw-stm32054.zip, the folder:

	STM32F10x_StdPeriph_Lib_V3.5.0/Libraries/CMSIS/CM3/DeviceSupport/ST/STM32F10x
	
The vectors_stm32f10x.c was created to conform to the startup_stm32f10x_xx*.s.